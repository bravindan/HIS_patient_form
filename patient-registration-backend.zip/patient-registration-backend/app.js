const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const connection = require('./db');
const nodemailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');

app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 5000;

app.post('/api/patient', async (req, res) => {
  try {
    const formData = req.body;
    // Save the form data into the database using the 'connection' object
    const query = 'INSERT INTO patients SET ?';

    connection.query(query, formData, (err, result) => {
      if (err) {
        console.error('Error saving data to the database:', err);
        res.status(500).json({ message: 'Internal Server Error' });
        return;
      }

      // get the patientID from 'result.insertId'
      const patientId = result.insertId;

      // Sending email to the patient
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'your-email@gmail.com', // Replace with your email
          pass: 'your-email-password', // Replace with your email password
        },
      });

      const patientRefNumber = uuidv4(); // Generate a patient reference number

      const mailOptions = {
        from: 'your-email@gmail.com',
        to: formData.email,
        subject: 'Patient Registration Successful',
        text: `Thank you for registering. Your patient reference number is: ${patientRefNumber}`,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error('Error sending email:', error);
        } else {
          console.log('Email sent:', info.response);
        }
      });

      // Respond with the patient reference number
      res.json({ patientRefNumber });
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
