
import './App.css'
import Patient_reg_form from './pages/Patient_reg_form'
function App() {

  return (
    <>
       < Patient_reg_form /> 
    </>
  )
}

export default App
