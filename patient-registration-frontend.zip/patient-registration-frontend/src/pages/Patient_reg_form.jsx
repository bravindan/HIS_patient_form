
import { useState } from "react";
import './regForm.css'

function Patient_reg_form() {
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    idNumber: '',
    address: '',
    county: '',
    subCounty: '',
    phone: '',
    email: '',
    gender: '',
    maritalStatus: '',
    nextOfKin: {
      name: '',
      dob: '',
      idNumber: '',
      gender: '',
      relationship: '',
      phone: '',
    },
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/patient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      console.log(formData);
      if (response.ok) {
        const data = await response.json();
        // the server sends back the patient reference number
        console.log('Patient Reference Number:', data.patientRefNumber);
      } else {
        console.error('Error submitting the form');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      
      <h2>Patient Registration Form</h2>
      <label>
        Telephone:
        <input
          type="text"
          name="telephone"
          value={formData.telephone}
          onChange={handleChange}
        />
      </label>
      <label>
        Name:
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
        />
      </label>
      <label>
        Date of Birth:
        <input
          type="date"
          name="dob"
          value={formData.dob}
          onChange={handleChange}
        />
      </label>
      <label>
        ID Number:
        <input
          type="text"
          name="idNumber"
          value={formData.idNumber}
          onChange={handleChange}
        />
      </label>
      <label>
        Address:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
        />
      </label>
      <label>
        County:
        <input
          type="text"
          name="county"
          value={formData.county}
          onChange={handleChange}
        />
      </label>
      <label>
        Sub County:
        <input
          type="text"
          name="subCounty"
          value={formData.subCounty}
          onChange={handleChange}
        />
      </label>
      <label>
        Phone:
        <input
          type="text"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
        />
      </label>
      <label>
        Email:
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
        />
      </label>
      <label>
        Gender:
        <input
          type="text"
          name="gender"
          value={formData.gender}
          onChange={handleChange}
        />
      </label>
      <label>
        Marital Status:
        <input
          type="text"
          name="maritalStatus"
          value={formData.maritalStatus}
          onChange={handleChange}
        />
      </label>

      {/* Next of Kin Details */}
      <h2>Next of Kin</h2>
      <label>
        Name:
        <input
          type="text"
          name="nextOfKin.name"
          value={formData.nextOfKin.name}
          onChange={handleChange}
        />
      </label>
      <label>
        Date of Birth:
        <input
          type="date"
          name="nextOfKin.dob"
          value={formData.nextOfKin.dob}
          onChange={handleChange}
        />
      </label>
      <label>
        ID Number:
        <input
          type="text"
          name="nextOfKin.idNumber"
          value={formData.nextOfKin.idNumber}
          onChange={handleChange}
        />
      </label>
      <label>
        Gender:
        <input
          type="text"
          name="nextOfKin.gender"
          value={formData.nextOfKin.gender}
          onChange={handleChange}
        />
      </label>
      <label>
        Relationship:
        <input
          type="text"
          name="nextOfKin.relationship"
          value={formData.nextOfKin.relationship}
          onChange={handleChange}
        />
      </label>
      <label>
        Phone:
        <input
          type="text"
          name="nextOfKin.phone"
          value={formData.nextOfKin.phone}
          onChange={handleChange}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
}

export default Patient_reg_form